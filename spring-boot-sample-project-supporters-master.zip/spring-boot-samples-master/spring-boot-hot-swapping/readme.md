## Hot swapping in Spring Boot with Eclipse STS

See more here:
http://blog.netgloo.com/2014/05/21/hot-swapping-in-spring-boot-with-eclipse-sts/
