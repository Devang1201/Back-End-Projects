package com.gfg.oop.polymorphism.runtime;

class Animal{
    public void animalSound(){
        System.out.println("Default Sound");
    }
}