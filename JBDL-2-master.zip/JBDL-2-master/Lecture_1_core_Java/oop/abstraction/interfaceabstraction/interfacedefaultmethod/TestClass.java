package com.gfg.oop.abstraction.interfaceabstraction.interfacedefaultmethod;

public class TestClass implements InterfaceWithDefaultMethod{
    // Driver Code
    public static void main (String[] args)
    {
        TestClass t = new TestClass();
        t.display();
    }
}
