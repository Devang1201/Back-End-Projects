package com.gfg.oop.abstraction.interfaceabstraction.interfaceexample;


public interface Vehicle {

    // all are the abstract methods.
    void changeGear(int a);
    void speedUp(int a);
    void applyBrakes(int a);
}
