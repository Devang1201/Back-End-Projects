package com.gfg.oop.inheritance.multilevel;

public class Parent extends GrandParent{

    public void Print() {
        System.out.println("Parent's Print()");
    }
}
