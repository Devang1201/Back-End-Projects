package com.gfg.oop.inheritance.multilevel;

public class GrandParent {

    public void Print() {
        System.out.println("Grandparent's Print()");
    }
}
