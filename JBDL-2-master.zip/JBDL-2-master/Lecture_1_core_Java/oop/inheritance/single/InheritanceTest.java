package com.gfg.oop.inheritance.single;

import com.gfg.oop.inheritance.single.MountainBike;

public class InheritanceTest // driver class

{
    public static void main(String args[])
    {

        MountainBike mb = new MountainBike(3, 100, 25);
        System.out.println(mb);

    }
}