package com.gfg.oop.inheritance.multiple;

public interface Second {

    void PrintSecond();
}
