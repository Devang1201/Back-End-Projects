package com.gfg.oop.inheritance.multiple;

public class MultipleInheritingClass implements First,Second {

    @Override
    public void PrintFirst() {

    }

    @Override
    public void PrintSecond() {

    }
}
