package com.gfg.oop.inheritance.multiple;

public interface First {
    void PrintFirst();
}
