public abstract class Animal {

    String color;
    float weight;
    public abstract void sound();
}
