public class AnimalManager {

    public void makeAnimalSound(Animal animal)
    {
        animal.sound();
    }
}
