public class Lion extends Animal {

    @Override
    public void sound() {
        System.out.println("Roar");

    }
}
