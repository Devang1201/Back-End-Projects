public class UserDetails {

    int balance;
    String userId;
}
