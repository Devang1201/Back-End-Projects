package com.example.jpaexample.demojpaexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJpaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
