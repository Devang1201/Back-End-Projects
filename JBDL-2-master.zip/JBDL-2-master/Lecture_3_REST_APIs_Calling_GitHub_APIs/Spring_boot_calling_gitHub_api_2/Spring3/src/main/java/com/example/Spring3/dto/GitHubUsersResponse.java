package com.example.Spring3.dto;

public class GitHubUsersResponse extends GitHubResponse<User> {
}
