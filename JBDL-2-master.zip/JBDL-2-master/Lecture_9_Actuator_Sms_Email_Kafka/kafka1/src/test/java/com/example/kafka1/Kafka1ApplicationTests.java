package com.example.kafka1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kafka1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
