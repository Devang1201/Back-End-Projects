package com.shashi.walletservice.Util;

import com.shashi.walletservice.Model.Transaction;

public class TransactionValidator {
    public boolean validateRequest (Transaction request){
        /*
        Write your logic to implement validation
         */
        return true;
    }
}
