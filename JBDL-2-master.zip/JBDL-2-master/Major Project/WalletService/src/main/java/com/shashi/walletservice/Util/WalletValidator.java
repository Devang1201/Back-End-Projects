package com.shashi.walletservice.Util;

import com.shashi.walletservice.Model.Wallet;

public class WalletValidator {
    public boolean validateWalletRequest(Wallet wallet){
        /*
        Write your logic to implement validation
         */
        return true;
    }
}
