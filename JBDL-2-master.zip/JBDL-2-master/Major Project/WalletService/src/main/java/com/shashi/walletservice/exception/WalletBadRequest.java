package com.shashi.walletservice.exception;

public class WalletBadRequest extends RuntimeException {
    public WalletBadRequest() {

        super("WalletBadRequest " );
    }
}
