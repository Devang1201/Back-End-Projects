package com.example.book.jpaexamplebook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaExampleBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
