package com.example.myldap.ldapspringsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LdapSpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(LdapSpringSecurityApplication.class, args);
	}

}
