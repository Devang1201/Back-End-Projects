package com.example.myldap.ldapspringsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LdapSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
