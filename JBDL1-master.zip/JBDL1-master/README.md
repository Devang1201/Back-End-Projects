# Java-Backend-Live-1
Lecture Wise content for the java backend dev course.

Description of Folder with respect to Lecture No.
# MultiThreading ->         Lecture 2 (By Piyush)
# Maven          ->         Lecture 3 (By Piyush)
# JDBC           ->         Lecture 3 (By Piyush)
# JPA-EXAMPLE-BOOK ->       Lecture 6 (By Piyush) 
# JPA-EXAMPLE-BOOK-JOINS -> Lecture 8 (By Piyush)
# FOR SPRING SECURITY USING OAUTH DOWNLOAD THE SOURCE CODE FROM https://spring.io/guides/tutorials/spring-boot-oauth2/
