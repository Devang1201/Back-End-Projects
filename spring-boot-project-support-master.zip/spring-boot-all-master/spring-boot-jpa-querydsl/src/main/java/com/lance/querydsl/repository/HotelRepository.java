package com.lance.querydsl.repository;

import org.springframework.data.repository.Repository;

import com.lance.querydsl.entity.HotelEntity;

public interface HotelRepository extends Repository<HotelEntity, Long>{

}
