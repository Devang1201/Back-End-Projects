package com.example.jpaexample.demojpaexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJpaExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoJpaExampleApplication.class, args);
	}

}
